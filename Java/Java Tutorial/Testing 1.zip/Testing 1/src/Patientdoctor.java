import java.util.*;

public class Patientdoctor {
    
    private Patient patient;
    private Doctor doctor;
    List<String> patientsNames = new ArrayList<String>();
    List<String> doctorNames = new ArrayList<String>();
    String[] patientList = new String[patientsNames.size()];
    String[][] doctorList = new String[doctorNames.size()][patientsNames.size() + 1];
        
    public void addPatient(Patient patient) {
        patientsNames.add(patient.getName());
        
    }
    
    public void addDoctor(Doctor doctor) {
        doctorNames.add(doctor.getName());
    }
    
    public void assignPatientToDoctor(){
        Object[] obj = doctorNames.toArray();
        Object[] obj2 = patientsNames.toArray();
        
        
        for(int i = 0; i < patientsNames.size(); i++){
            patientList[i] = (String)obj2[i];
        }
        for(int i = 0; i < doctorNames.size(); i++){
            doctorList[i][0] = (String)obj[i]; 
        }
        
        System.out.println("Select a patient: [" );
        for(int i = 0; i < patientList.length; i++){
            System.out.print(i + "]"  + patientList[i] + " ");
        }
        Scanner in = new Scanner(System.in);
        
        int selection = in.nextInt();
        
        System.out.println("Select a doctor: [");
        for(int i = 0; i < doctorList[i][0].length(); i++){
            System.out.print(i + "]"  + doctorList[i] + " ");
        }
        int selection2 = in.nextInt();
        
        for(int i = 0; i < doctorList.length; i++){
            
            doctorList[selection2][i+1] = patientsNames.get(selection);
            
            
        }
        
        in.close();
    }
    
    public void showPatientDoctor(){
        System.out.println("Doctor info: ");
        for(int i = 0; i < doctorNames.size(); i++){
            System.out.println("[" + i + "] " + doctorNames.get(i));
        }
        Scanner in = new Scanner(System.in);
        System.out.print("Name: ");
        int sel = in.nextInt();
        
        System.out.println("Patient info");
        for(int j = 1; j < doctorList.length; j++){
            System.out.println(j + "Name: " + doctorList[sel][j]);
        }
        
        in.close();
    }
    
    
}
