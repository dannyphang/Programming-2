public class Patient extends Person{
    private String disease;

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }
    
    public Patient(String name, String gender, int age){
        this.name = name;
        this.gender = gender;
        this.age = age;
    }
    
    public void print(){
        Patient patient = new Patient(name, gender, age);
        System.out.print("Data that you stored\nName: " + patient.getName() + "\nAge: " + patient.getAge() + "\nGender: " + patient.getGender() + "\nDisease: ");
    }
}
