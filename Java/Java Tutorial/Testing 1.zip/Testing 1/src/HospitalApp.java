import java.util.Scanner;
public class HospitalApp {
    public static void main(String[] args) {
        String name="";
        int age=0;
        String gender="";
        Patientdoctor hospital = new Patientdoctor();
        
        while(true){
            System.out.println("WELCOME TO KUANTAN HOSPITAL DOCOTR-PATIENT SYSTEM\n" + "\nMENU : \n" + "\n 1 Add Patient " + "\n 2 Add Doctor " + "\n 3 Assign Doctor to Patients" + "\n 4 Show Doctor and Their Patients " + "\n Your choice : ");
            int choice = getScanner().nextInt();
            switch (choice){
                case 1:
                    System.out.println("Your choice is : " + choice);
                    System.out.println("Add Patient Info\n");
                    Scanner s = getScanner();
                    
                    System.out.print("Name : ");
                    name = s.next();
                    
                    System.out.print("Age : ");
                    age = s.nextInt();
                    
                    System.out.print("Gender : ");
                    gender = s.next();
                    
                    Patient patient = new Patient(name, gender, age);
                    patient.setName(name);
                    patient.setGender(gender);
                    patient.setAge(age);
                    
                    System.out.println("Disease : 1) Cancer, 2) Diabetes, 3) Heart Attack \n");
                    String disease = "";
                    
                    int point1 = s.nextInt();
                    
                    if(point1==1){
                        disease = Disease.CANCER;
                    }else if(point1 == 2){
                        disease = Disease.DIABETES;
                    }else if(point1 == 3){
                        disease = Disease.HEART;
                    }
                    patient.setDisease(disease);
                    
                    patient.print();
                    System.out.println(patient.getDisease());
                    hospital.addPatient(patient);
                    break; 
                case 2:
                    System.out.println("Your choice is: " + choice);

                    System.out.println("Add Doctor Info \n");
                    Scanner s2 = getScanner();
                    
                    System.out.print("Name : ");
                    name = s2.next();
                    
                    System.out.print("Age : ");
                    age = s2.nextInt();
                    
                    System.out.print("Gender : ");
                    gender = s2.next();
                    
                    Doctor doctor = new Doctor(name, gender, age);
                    doctor.setName(name);
                    doctor.setAge(age);
                    doctor.setGender(gender);
                    
                    System.out.println("Expertise : 1)Cancer, 2) Diabetes, 3) Heart Attack \n");
                    String speciality = "";
                    int point=s2.nextInt();
                    if(point == 1){
                        speciality = Disease.CANCER;
                    }else if(point == 2){
                        speciality = Disease.DIABETES;
                    }else if(point == 3){
                        speciality = Disease.HEART;
                    }
                    
                    doctor.setExpertise(speciality);
                    doctor.print();
                    System.out.println(doctor.getExpertise());
                    hospital.addDoctor(doctor);
                    break;
                case 3 :
                    System.out.println();
                    hospital.assignPatientToDoctor();
                    System.out.println("Assigned!");
                    break;
                case 4 :
                    hospital.showPatientDoctor();
                    System.exit(0);
                    break; 
            }
        }
    }

    private static Scanner getScanner(){
        Scanner cin = new Scanner (System.in);
        return cin;
    }
    
}

class Disease {
    public static final String CANCER = "Cancer";
    public static final String DIABETES = "Diabetes";
    public static final String HEART = "Heart Attack";
}
