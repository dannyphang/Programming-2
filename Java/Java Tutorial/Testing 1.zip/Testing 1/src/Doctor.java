import java.util.*;

public class Doctor extends Person{
    
    private Patient patient;
    private String expertise;
    List<String> assignPatients = new ArrayList<String>();
    
    public Doctor(String name, String gender, int age){
        this.name = name;
        this.gender = gender;
        this.age = age;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }
    
    public void addPatient(Patient patient) {
        
        assignPatients.add(patient.getName());
        
    }
    
    public void print() {
        Doctor doctor = new Doctor(name, gender, age);
        System.out.print("Data that you stored\nName: " + doctor.getName() + "\nAge: " + doctor.getAge() + "\nGender: " + doctor.getGender() + "\nExpertise: ");
    }
}
